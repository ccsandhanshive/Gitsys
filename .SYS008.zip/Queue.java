
public class Queue {
	private int front;
	private int rear;
	private int max=1000;
	private int[] array=new int[max];
	Queue(){
		this.front=-1;
		this.rear=-1;
	}
	boolean isFull() {
		if(rear>max)
			return true;
		else
			return false;
	}
	boolean isEmpty() {
		if(this.front>this.rear) {
			return true; }
		else
			return false;
	}
	void enQueue(int element) {
		if(front==-1)
			front=0;
		if(!isFull()) {
			rear++;
			array[rear]=element;
		}else {
			System.err.println("Queue is Full");
		}
	}
	int deQueue() {
		int ele;
		if(!isEmpty()) {
			ele=array[front];
			front++;
			return ele;
			
		}else {
			System.err.print("Queue isEmpty");
			return -1;
		}
	}
	int peek() {
		return array[front];
	}
	void printQueue() {
		for(int i=front;i<=rear;i++) {
			System.out.print(array[i]+",");
		}
		System.out.println();
	}
	public static void main(String args[]) {
		Queue q=new Queue();
		q.enQueue(1);
		q.enQueue(2);
		q.enQueue(3);
		q.printQueue();
		System.out.println("deleted element is"+q.deQueue());
		q.printQueue();
		System.out.println("deleted element is"+q.deQueue());
		q.printQueue();
		System.out.println("deleted element is"+q.deQueue());
		q.printQueue();
		q.deQueue();
		
	}
	

}
//enqueue=r++,dequeue,peek,f=top,isfull,isempty,